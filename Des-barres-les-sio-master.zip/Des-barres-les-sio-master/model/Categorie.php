<?php
class Categorie extends Model
{
    var $table="categorie";  
}

?>