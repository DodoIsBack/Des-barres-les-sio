<?php
class Auteur extends Model
{
  var $table="auteur";  
  
 
}

?>