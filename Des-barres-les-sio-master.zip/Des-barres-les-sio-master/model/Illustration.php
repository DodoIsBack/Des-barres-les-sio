<?php
class Illustration extends Model
{
    var $table="illustration";  
}

?>