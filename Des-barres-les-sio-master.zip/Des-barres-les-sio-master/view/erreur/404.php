<div class="row">
<div class="text-center col-md-12" style="padding-top:2.5em"><h1>Oupss!</h1></div>
<div class="text-center col-md-12" id="erreur"></div>
</div>