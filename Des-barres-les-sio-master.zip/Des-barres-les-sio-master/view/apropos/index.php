<!-- Services -->
  <section class="page-section" id="apropos">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase">A propos</h2>
          <h3 class="section-subheading text-muted">les fameuses blagues des BTS SIO 2 SLAM.</h3>
        </div>
      </div>
      <div class="row text-center">
        <div class="col-md-4 col-xs-12">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-shopping-cart fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading">E-Commerce</h4>
          <p class="text-muted">Vous avez la possibilit&eacute; d'acheter des blagues</p>
        </div>
        <div class="col-md-4 col-xs-12">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-laptop fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading">Visualiser les blagues</h4>
          <p class="text-muted">Les blagues sont disponibles via vos ordinateurs et les smartphones.</p>
        </div>
        <div class="col-md-4 col-xs-12">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-lock fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading">Se connecter</h4>
          <p class="text-muted">Inscrivez -vous pour acheter des blagues</p>
        </div>
      </div>
    </div>
  </section>