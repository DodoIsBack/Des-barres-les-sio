  <section class="page-section" id="commanderfinaliser">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
			<h1>Merci de nous avoir accordé votre confiance !</h1>
			<br> <br>
			<h5> Votre paiement a bien été effectué ! </h5>

<a href="<?= WEBROOT.'blague' ?>">
	<button type="button" style="margin:20px" >
		POURSUIVRE 
	</button>
</a>
</div>
</div>
</div>
</section>